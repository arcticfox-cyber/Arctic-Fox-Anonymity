#!/usr/bin/env bash
#===============================================================================
#  Arctic Fox Anonymity - Uninstaller
#  Stops routing (if active), removes the arcticfox command and cleans up.
#  Usage:  sudo bash uninstall.sh
#===============================================================================
set -u

if [ -t 1 ]; then
    C_R=$'\e[1;31m'; C_G=$'\e[1;32m'; C_Y=$'\e[1;33m'
    C_C=$'\e[1;36m'; C_W=$'\e[1;37m'; C_0=$'\e[0m'
else
    C_R=""; C_G=""; C_Y=""; C_C=""; C_W=""; C_0=""
fi

ok()   { printf '%s[+]%s %s\n' "$C_G" "$C_0" "$*"; }
err()  { printf '%s[-]%s %s\n' "$C_R" "$C_0" "$*"; }
info() { printf '%s[*]%s %s\n' "$C_C" "$C_0" "$*"; }
die()  { err "$*"; exit 1; }

TORRC="/etc/tor/torrc"
TORRC_MARKER="# === Arctic Fox Anonymity configuration ==="
TORRC_END="# === End Arctic Fox Anonymity ==="
BACKUP_DIR="/var/lib/arcticfox"

printf '\n  %sArctic Fox Anonymity - Uninstaller%s\n\n' "$C_W" "$C_0"

[ "$(id -u)" -eq 0 ] || die "Uninstaller must run as root.  Use:  sudo bash uninstall.sh"

#--- 1. If routing is active, stop it safely -------------------------------------
if [ -x /usr/local/bin/arcticfox ]; then
    info "Stopping any active anonymous routing..."
    /usr/local/bin/arcticfox -y stop >/dev/null 2>&1 || true
    ok "Routing stopped (if it was active)."
fi

#--- 2. Remove the command and assets --------------------------------------------
info "Removing /usr/local/bin/arcticfox ..."
rm -f /usr/local/bin/arcticfox

# Remove OUR bulletproof symlink (only if it points to our tool - never touch others)
if [ -L /usr/bin/arcticfox ] && [ "$(readlink /usr/bin/arcticfox)" = "/usr/local/bin/arcticfox" ]; then
    rm -f /usr/bin/arcticfox
    ok "Removed /usr/bin/arcticfox symlink."
fi

info "Removing /usr/share/arcticfox ..."
rm -rf /usr/share/arcticfox

rm -f /etc/bash_completion.d/arcticfox 2>/dev/null

#--- 3. Clean torrc ---------------------------------------------------------------
if [ -f "$TORRC" ] && grep -qs "$TORRC_MARKER" "$TORRC"; then
    info "Removing Arctic Fox block from $TORRC ..."
    sed -i "\\|$TORRC_MARKER|,\\|$TORRC_END|d" "$TORRC"
    ok "Tor configuration cleaned."
fi

#--- 4. Remove backups ------------------------------------------------------------
if [ -d "$BACKUP_DIR" ]; then
    info "Removing backup directory $BACKUP_DIR ..."
    rm -rf "$BACKUP_DIR"
fi

echo ""
ok "Arctic Fox Anonymity has been completely removed."
info "Note: the 'tor' package is still installed. Remove it with:  sudo apt purge tor"
echo ""
