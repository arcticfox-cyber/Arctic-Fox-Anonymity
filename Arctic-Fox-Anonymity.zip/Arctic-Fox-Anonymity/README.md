<div align="center">

<img src="logo.png" alt="Arctic Fox Anonymity" width="260"/>

# 🦊 Arctic Fox Anonymity

**Transparent Tor routing for Kali Linux — anonymize your ENTIRE operating system.**

`v1.0.2` · Bash · Kali / Debian based systems

*Inspired by AnonGT / anonsurf — rebuilt cleaner, safer and easier to install.*

</div>

---

## What is it?

**Arctic Fox Anonymity** redirects **all traffic of your Kali Linux system** — every TCP
connection **and every DNS query** — through the **Tor network**. Unlike browser VPN
extensions or `proxychains` (which only cover single apps), this tool anonymizes the whole
operating system at the firewall level. Open Firefox, run `nmap`, use `sqlmap`, chat, game
update checks — everything goes through Tor automatically.

## Features

| Feature | Description |
| --- | --- |
| 🌐 **Full transparent routing** | All TCP traffic redirected to Tor's `TransPort` (9040) via iptables — no proxy settings needed in apps |
| 🔎 **DNS through Tor** | All DNS (UDP + TCP 53) forced to Tor's `DNSPort` (5353) — no DNS leaks |
| 🚫 **UDP leak protection** | Non-DNS UDP (QUIC/HTTP3, WebRTC-style) is rejected — apps silently fall back to TCP |
| 🚫 **ICMP blocked** | Ping cannot be proxied through Tor, so it is blocked instead of leaking destinations |
| 🧊 **IPv6 lock** | IPv6 output is blocked while routing — no IPv6 leaks |
| 🛡️ **Non-destructive firewall** | Uses its own iptables chains (`AF_NAT`, `AF_FILT`, `AF_FILT6`) — your existing firewall rules are **not** wiped (unlike AnonGT) |
| 💾 **Auto backup & restore** | `resolv.conf` and firewall snapshots saved to `/var/lib/arcticfox` and restored on stop |
| 🔄 **Identity change** | `arcticfox changeip` requests a fresh Tor circuit (NEWNYM) |
| 🎛️ **Menu + CLI flags** | Interactive menu (like AnonGT) *and* proper `start/stop/status` commands |
| 📦 **Clean install/uninstall** | `install.sh` puts the tool in `/usr/local/bin` with bash completion; `uninstall.sh` removes everything |

## Install (Kali Linux)

```bash
# 1. Open the Arctic-Fox-Anonymity folder
cd Arctic-Fox-Anonymity

# 2. Run the installer (installs tor, curl, iptables + the arcticfox command)
sudo bash install.sh
```

That's it. The `arcticfox` command now works from **any terminal**, just like a native Kali tool.

## Usage

```bash
sudo arcticfox start     # route ALL traffic through Tor
sudo arcticfox status    # verify you are behind Tor
sudo arcticfox changeip  # get a new Tor identity / circuit
sudo arcticfox stop      # restore normal internet
sudo arcticfox menu      # interactive menu (also: just run 'arcticfox')
```

<details>
<summary><b>All commands</b></summary>

| Command | Action |
| --- | --- |
| `start` | Start anonymous routing (TCP + DNS → Tor) |
| `stop` | Stop routing, restore your original DNS and firewall |
| `restart` | Stop + start with a fresh Tor circuit |
| `status` | Tor service, routing, IPv6, DNS and IP status |
| `changeip` | Request new Tor circuit (NEWNYM signal) |
| `ip` | Show the public IP websites see right now + Tor SOCKS IP |
| `menu` | Interactive numbered menu (default when run without args) |
| `banner` | Show the Arctic Fox banner |
| `version` | Print version |
| `-y, --yes` | Flag: skip confirmation prompts (useful in scripts) |

</details>

### Example: start

```
[?] Route ALL traffic through Tor? (connections will reset briefly) [y/N]: y
[*] Step 1/5  Configuring Tor (transparent proxy + DNS)...
[+] Tor transparent-proxy configuration written to /etc/tor/torrc
[*] Step 2/5  Restarting the Tor service...
[*] Step 3/5  Bootstrapping Tor...
   [*] Waiting for Tor to build a circuit ............
[*] Step 4/5  Applying firewall rules (backup saved to /var/lib/arcticfox)...
[*] Step 5/5  Forcing system DNS through Tor...

  +--------------------------------------------------+
  |  ARCTIC FOX ANONYMITY - ACTIVE                   |
  |  Tor exit IP : 185.220.xxx.xxx                   |
  |  DNS         : routed through Tor (127.0.0.1)    |
  |  IPv6        : blocked (leak protection)         |
  |  Ping (ICMP) : blocked (cannot be proxied)       |
  +--------------------------------------------------+
[+] All traffic is now going through the Tor network.
```

## How it works

1. **Tor configuration** — `install.sh` / first `start` appends a marked block to
   `/etc/tor/torrc`: `TransPort 9040`, `DNSPort 5353`, `SocksPort 9050`,
   `ControlPort 9051`, `VirtualAddrNetworkIPv4 10.192.0.0/10`, `AutomapHostsOnResolve 1`.
2. **iptables** — on `start` a custom NAT chain redirects all output TCP to Tor's
   transparent port and DNS to Tor's DNS resolver. Tor's own traffic is exempted
   (`--uid-owner debian-tor`) so no routing loop happens. LAN ranges and loopback stay direct.
3. **Leak protection** — remaining UDP is rejected, ICMP is rejected, IPv6 output is rejected.
4. **Restore** — `stop` removes only the Arctic Fox chains, restores your original
   `resolv.conf` and stops the Tor service. Your system is exactly as it was before.

**Verify anytime:** run `arcticfox status` — it queries `check.torproject.org` and shows
whether you are **really** behind Tor (`Tor: YES`) or not.

## Troubleshooting

| Problem | Fix |
| --- | --- |
| `ModuleNotFoundError: No module named 'core'` (Python traceback) | An old, unrelated Python tool also named `arcticfox` is shadowing ours. **One-shot fix (included):** `sudo bash fix_arcticfox.sh` — it renames the old tool, makes a bulletproof `/usr/bin/arcticfox` symlink and verifies both `arcticfox version` and `sudo arcticfox version` |
| `arcticfox` runs the wrong tool after install | `hash -r` or open a new terminal (bash caches command paths) |
| `Tor failed to build a circuit` | Check your internet; on censored networks configure Tor bridges in `/etc/tor/torrc`, then `sudo arcticfox restart` |
| Tor won't start after install | Duplicate port in your custom `torrc`? Remove old `TransPort`/`DNSPort` lines, keep only the Arctic Fox block |
| Ping does not work while routing | By design — ICMP cannot go through Tor. Stop routing to ping |
| Some UDP app fails (Voice/QUIC) | By design — UDP is rejected. TCP fallback is automatic |
| Want the old firewall back manually | `sudo iptables-restore < /var/lib/arcticfox/iptables.v4.bak` |
| Broke `resolv.conf` manually | `sudo cp /var/lib/arcticfox/resolv.conf.bak /etc/resolv.conf` |

## Uninstall

```bash
sudo bash uninstall.sh     # from the repo folder — removes everything cleanly
```

## Roman Urdu — Quick Start (فوری رہنمائی)

> **Note (Urdu/Hindi users):** Ye tool poore Kali Linux ka internet Tor ke through bhejta hai.
> Install: `sudo bash install.sh` · Chalao: `sudo arcticfox start` · Band karo: `sudo arcticfox stop`
> · Check karo: `arcticfox status`. sirf legal pentesting aur privacy ke liye use karo! 🦊

## Disclaimer

⚠️ **For legal and ethical use only.** Arctic Fox Anonymity is intended for authorized
penetration testing, security research, OSINT and personal privacy on systems you own or
have permission to test. Anonymity is not a license for crime — Tor exit activity can still
be monitored by exit nodes, and using anonymity tools does not make illegal actions legal.
The authors take no responsibility for misuse.

## License

MIT — see [LICENSE](LICENSE).
